// Validation errors messages for Parsley
import Parsley from '../parsley';

Parsley.addMessages('sv', {
  dateiso: "Ange ett giltigt datum (ÅÅÅÅ-MM-DD)."
});
